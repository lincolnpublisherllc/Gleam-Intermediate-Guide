git add .
git commit -m "Description of the changes made"
