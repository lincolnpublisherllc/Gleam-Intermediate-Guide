git checkout -b feature/adding-new-endpoint
Pull Requests (PRs) and Code Reviews:
Before merging code, use Pull Requests (PRs) to request feedback from your collaborators.
