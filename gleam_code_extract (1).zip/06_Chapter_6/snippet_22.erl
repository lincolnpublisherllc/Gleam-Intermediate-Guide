dbg:tracer().
dbg:p(all, call).
