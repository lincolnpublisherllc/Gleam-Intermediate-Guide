gleam new json_example
cd json_example
