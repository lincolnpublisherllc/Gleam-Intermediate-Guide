gleam run
This will read the input.json file, process the data, and write a new JSON file (output.json) with the following content:
