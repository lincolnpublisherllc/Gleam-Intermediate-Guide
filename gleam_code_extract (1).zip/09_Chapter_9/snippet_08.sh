Observer:
For debugging and performance monitoring, Observer (a tool from Erlang) allows you to visualize the state of your application. It can provide insights into processes, memory usage, and much more.
To launch Observer, you can run:
erl -s observer
