gleam new my_project
cd my_project
