Adding Dependencies:
To add a package (for example, a utility library), you can use the gleam add command:
gleam add gleam/json  # Adds the json package to your project
Checking for Available Packages:
Gleam packages are hosted on Hex.pm (the same repository used by Erlang and Elixir). You can search for available packages using the official website or through the command line.
