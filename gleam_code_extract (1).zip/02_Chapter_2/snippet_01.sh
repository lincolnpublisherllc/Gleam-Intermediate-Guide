macOS: If you are using Homebrew (a package manager for macOS), you can install Gleam with the following command:
brew install gleam-lang/tap/gleam
