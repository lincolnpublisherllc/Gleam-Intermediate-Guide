sudo apt install gleam  # For Ubuntu-based systems
