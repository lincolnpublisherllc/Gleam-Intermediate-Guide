gleam remove gleam/json  # Removes the json package
