sudo apt install erlang
