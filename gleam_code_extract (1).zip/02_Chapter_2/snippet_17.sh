gleam/json = "~> 1.0"  # Any version 1.0.x, but not 2.0.0
