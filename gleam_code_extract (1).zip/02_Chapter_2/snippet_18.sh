gleam new my_project
