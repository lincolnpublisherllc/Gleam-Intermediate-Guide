gleam new todo_app
cd todo_app
