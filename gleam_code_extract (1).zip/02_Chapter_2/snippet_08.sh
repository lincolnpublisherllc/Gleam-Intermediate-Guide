gleam new my_first_project  # Creates a new Gleam project
cd my_first_project
gleam run  # Runs the project
