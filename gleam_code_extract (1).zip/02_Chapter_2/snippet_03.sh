choco install gleam
Setting Up the BEAM VM (Erlang):
Since Gleam compiles to the BEAM virtual machine, you must have Erlang installed on your system. Here’s how to set it up:
