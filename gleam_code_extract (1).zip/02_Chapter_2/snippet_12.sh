gleam add gleam/json  # Adds JSON parsing library
