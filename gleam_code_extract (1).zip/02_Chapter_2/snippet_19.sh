gleam.toml: The configuration file for your project.
gleam.lock: A lock file that records the exact versions of dependencies.
