Gleam Intermediate Guide — Code Extraction
Grouped by chapter using heuristics. See manifest.csv for details.
Filename pattern: Chapter_##/snippet_##.<ext>
